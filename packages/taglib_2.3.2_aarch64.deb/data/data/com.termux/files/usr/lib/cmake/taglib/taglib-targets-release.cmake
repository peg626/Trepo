#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "TagLib::tag" for configuration "Release"
set_property(TARGET TagLib::tag APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TagLib::tag PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.termux/files/usr/lib/libtag.so"
  IMPORTED_SONAME_RELEASE "libtag.so"
  )

list(APPEND _cmake_import_check_targets TagLib::tag )
list(APPEND _cmake_import_check_files_for_TagLib::tag "/data/data/com.termux/files/usr/lib/libtag.so" )

# Import target "TagLib::tag_c" for configuration "Release"
set_property(TARGET TagLib::tag_c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(TagLib::tag_c PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "TagLib::tag"
  IMPORTED_LOCATION_RELEASE "/data/data/com.termux/files/usr/lib/libtag_c.so"
  IMPORTED_SONAME_RELEASE "libtag_c.so"
  )

list(APPEND _cmake_import_check_targets TagLib::tag_c )
list(APPEND _cmake_import_check_files_for_TagLib::tag_c "/data/data/com.termux/files/usr/lib/libtag_c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
