// Copyright © 2002-2010 Steve Lhomme.
// SPDX-License-Identifier: LGPL-2.1-or-later

/*!
  \file
  \version \$Id: EbmlVoid.h 1079 2005-03-03 13:18:14Z robux4 $
  \author Steve Lhomme     <robux4 @ users.sf.net>
*/
#ifndef LIBEBML_VOID_H
#define LIBEBML_VOID_H

#include "EbmlTypes.h"
#include "EbmlBinary.h"

namespace libebml {

DECLARE_EBML_BINARY(EbmlVoid)
  public:
    EbmlVoid(const EbmlVoid & ElementToClone) = default;

    /*!
      \brief Set the size of the data (not the complete size of the element)
    */
    void SetSize(uint64 aSize) {SetSize_(aSize);}

    /*!
      \note overwrite to write fake data
    */
    filepos_t RenderData(IOCallback & output, bool bForceRender, bool bWithDefault = false) override;

    /*!
      \brief Replace the void element content (written) with this one
    */
    uint64 ReplaceWith(EbmlElement & EltToReplaceWith, IOCallback & output, bool ComeBackAfterward = true, bool bWithDefault = false);

    /*!
      \brief Void the content of an element
    */
    uint64 Overwrite(const EbmlElement & EltToVoid, IOCallback & output, bool ComeBackAfterward = true, bool bWithDefault = false);

        EBML_CONCRETE_CLASS(EbmlVoid)
};

} // namespace libebml

#endif // LIBEBML_VOID_H
